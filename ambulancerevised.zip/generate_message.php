 <html>
  <head>
      <title>SORRY</title>
	  <link href="css/style.css" rel="stylesheet" type="text/css" />
  </head>
<?php

echo "<h4 style='color:#fff; margin:20px'>Sorry. you do not have any pending request</h4>";

?>

   </body>
 </html>